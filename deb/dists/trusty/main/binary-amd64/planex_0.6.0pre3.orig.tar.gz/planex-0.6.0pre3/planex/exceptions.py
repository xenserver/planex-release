class NoSuchFile(Exception):
    pass


class InvalidURL(Exception):
    pass


class NoRepository(Exception):
    pass

