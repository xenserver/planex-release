#!/bin/bash
. env/bin/activate
cd /planex
tox


