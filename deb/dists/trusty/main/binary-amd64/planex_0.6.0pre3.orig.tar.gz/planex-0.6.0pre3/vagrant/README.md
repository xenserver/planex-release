This directory contains a vagrant config to run the unit tests

Usage:

vagrant up
vagrant ssh -c ./test.sh

