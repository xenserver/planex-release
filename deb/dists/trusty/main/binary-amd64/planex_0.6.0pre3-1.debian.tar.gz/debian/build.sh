#!/bin/sh
unset CFLAGS
/usr/bin/python setup.py build

