#!/bin/sh
 /bin/rm -rf ${DESTDIR}
