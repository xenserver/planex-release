#!/bin/sh
/usr/bin/python setup.py install --single-version-externally-managed -O1 --root=${DESTDIR} --record=INSTALLED_FILES

